var cowsay = require("cowsay");

console.log(cowsay.think({
    text : "I'm a moooodule",
    e : "0O",
    T : "{} ",
    Mode: "Borg"
}));